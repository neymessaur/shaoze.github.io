//
//  main.c
//  project4
//
//  Created by 益佳宇 on 2018/11/28.
//  Copyright © 2018年 益佳宇. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#define NUMMEMORY 65536 /* maximum number of words in memory */
#define NUMREGS 8 /* number of machine registers */
#define MAXLINELENGTH 1000
#define valid_bit 1
#define dirty_bit 1

typedef struct stateStruct {
    int pc;
    int mem[NUMMEMORY];
    int reg[NUMREGS];
    int numMemory;
} stateType;

int convertNum(int num){
    if (num & (1<<15)){
        num -= (1<<16);
    }
    return (num);
}

enum actionType
{cacheToProcessor, processorToCache, memoryToCache, cacheToMemory,
    cacheToNowhere};

int cache[256][256+1+1+1+1];//每一行就是一个block，第一个是valid，第二个是dirty，第三个是tag，第四个是LRU
int blockSizeInWords;
int numberOfSets;
int blocksPerSet;
int blockoffset_bit;
int set_idx_bit;
int tag_bit;
int totalblocks;
stateType state;
void
printAction(int address, int size, enum actionType type)
{
    printf("@@@ transferring word [%d-%d] ", address, address + size - 1);
    if (type == cacheToProcessor) {
        printf("from the cache to the processor\n");
    } else if (type == processorToCache) {
        printf("from the processor to the cache\n");
    } else if (type == memoryToCache) {
        printf("from the memory to the cache\n");
    } else if (type == cacheToMemory) {
        printf("from the cache to the memory\n");
    } else if (type == cacheToNowhere) {
        printf("from the cache to nowhere\n");
    }
}

int load(int addr){
    enum actionType temp;
    int result = 0;
    int blockoffset = addr % blockSizeInWords;
    int set_idx = (addr/blockSizeInWords)%numberOfSets;
    int tag = addr/blockSizeInWords/numberOfSets;
    //now decide which row it belongs
    int row;
    row = set_idx*blocksPerSet;
    //search for the address in the cache
    int search_success = 0;
    for (unsigned int i=0; i<blocksPerSet; i++){
        if (cache[row+i][0] == 1 && cache[row+i][2] == tag){
            for (unsigned int j=0; j<blocksPerSet; j++){
                if (cache[row+j][0] == 1 && j!=i && cache[row+j][3] < cache[row+i][3])
                    cache[row+j][3]++;
            }
            cache[row+i][3] = 0;
            result = cache[row+i][4+blockoffset];
            search_success = 1;
            break;
        }
    }
    if(!search_success){
        //首先判断set里面还有没有空位能够放下这个block，其次再evict
        int vacant = 0;
        unsigned int available_slot = 0;
        for (unsigned int i=0; i<blocksPerSet; i++){
            if (cache[row+i][0] == 0){
                vacant = 1;
                available_slot = i;
                break;
            }
        }
        if (vacant == 0){
            unsigned int to_be_replaced = 0;
            for (unsigned int i=0; i<blocksPerSet; i++){
                if (cache[row+i][3] == blocksPerSet - 1){
                    to_be_replaced = i;
                    break;
                }
            }
            int evicted = 0;
            evicted = cache[row+to_be_replaced][2]*blockSizeInWords*numberOfSets + set_idx*blockSizeInWords;
            if (cache[row+to_be_replaced][1] == 1){
                temp = cacheToMemory;
                for (size_t i=0; i<blockSizeInWords; i++){
                    state.mem[evicted+i] = cache[row+to_be_replaced][4+i];
                }
            }
            else
                temp = cacheToNowhere;
            printAction(evicted, blockSizeInWords, temp);
            available_slot = to_be_replaced;
        }
        cache[row+available_slot][0] = 1;
        cache[row+available_slot][1] = 0;
        cache[row+available_slot][2] = tag;
        cache[row+available_slot][3] = 0;
        for (unsigned int j=0; j<blocksPerSet; j++){
            if (cache[row+j][0] == 1 && j!=available_slot){
                cache[row+j][3]++;
            }
        }
        for (unsigned int j=4; j<blockSizeInWords+4; j++){
            cache[row+available_slot][j] = state.mem[(addr/blockSizeInWords)*blockSizeInWords+j-4];
        }
        temp = memoryToCache;
        printAction((addr/blockSizeInWords)*blockSizeInWords, blockSizeInWords, temp);
        result = cache[row+available_slot][4+blockoffset];
    }
    temp = cacheToProcessor;
    printAction(addr, 1, temp);
    /*
    for (unsigned int i=0; i<numberOfSets*blocksPerSet; i++){
       printf("%d ",cache[i][3]);
    }
    printf("\n");
     */
    return result;
}

void store(int addr, int data){
    enum actionType temp;
    int blockoffset = addr % blockSizeInWords;
    int set_idx = (addr/blockSizeInWords)%numberOfSets;
    int tag = addr/blockSizeInWords/numberOfSets;
    //now decide which row it belongs
    int row;
    row = set_idx*blocksPerSet;
    //search for the address in the cache
    int search_success = 0;
    for (unsigned int i=0; i<blocksPerSet; i++){
        if (cache[row+i][0] == 1 && cache[row+i][2] == tag){
            for (unsigned int j=0; j<blocksPerSet; j++){
                if (cache[row+j][0] == 1 && j!=i && cache[row+j][3] < cache[row+i][3]) cache[row+j][3]++;
            }
            cache[row+i][3] = 0;
            cache[row+i][4+blockoffset] = data;
            cache[row+i][1] = 1;
            search_success = 1;
            break;
        }
    }
    if(!search_success){
        //首先判断set里面还有没有空位能够放下这个block，其次再evict
        int vacant = 0;
        unsigned int available_slot = 0;
        for (unsigned int i=0; i<blocksPerSet; i++){
            if (cache[row+i][0] == 0){
                vacant = 1;
                available_slot = i;
                break;
            }
        }
        if (vacant == 0){
            unsigned int to_be_replaced = 0;
            for (unsigned int i=0; i<blocksPerSet; i++){
                if (cache[row+i][3] == blocksPerSet - 1){
                    to_be_replaced = i;
                    break;
                }
            }
            int evicted = 0;
            evicted = cache[row+to_be_replaced][2]*blockSizeInWords*numberOfSets + set_idx*blockSizeInWords;
            if (cache[row+to_be_replaced][1] == 1){
                temp = cacheToMemory;
                for (size_t i=0; i<blockSizeInWords; i++){
                    state.mem[evicted+i] = cache[row+to_be_replaced][4+i];
                }
            }
            else
                temp = cacheToNowhere;
            printAction(evicted, blockSizeInWords, temp);
            available_slot = to_be_replaced;
        }
        cache[row+available_slot][0] = 1;
        cache[row+available_slot][1] = 0;
        cache[row+available_slot][2] = tag;
        cache[row+available_slot][3] = 0;
        for (unsigned int j=0; j<blocksPerSet; j++){
            if (cache[row+j][0] == 1 && j!=available_slot) cache[row+j][3]++;
        }
        for (unsigned int j=4; j<blockSizeInWords+4; j++){
            cache[row+available_slot][j] = state.mem[(addr/blockSizeInWords)*blockSizeInWords+j-4];
        }
        temp = memoryToCache;
        printAction((addr/blockSizeInWords)*blockSizeInWords, blockSizeInWords, temp);
        cache[row+available_slot][4+blockoffset] = data;
        cache[row+available_slot][1] = 1;
    }
    temp = processorToCache;
    printAction(addr, 1, temp);
}

int modifyState(stateType *statePtr){
    int machine_code = load(statePtr->pc);
    int ins_bit = (machine_code>>22) & (0b111);
    int regA;
    int regB;
    int offsetField;
    int destreg;
    if (ins_bit == 0b010 || ins_bit == 0b011 || ins_bit == 0b100){
        regA = (machine_code>>19) & (0b111);
        regB = (machine_code>>16) & (0b111);
        offsetField = convertNum((machine_code) & (0xFFFF));
        if (ins_bit == 0b010){
            //printf("The simulator has met a lw\n");
            int load_num = load(statePtr->reg[regA]+offsetField);
            statePtr->reg[regB] = load_num;
            statePtr->pc ++;
            //printf("pc is %d",statePtr->pc);
        }
        else if (ins_bit == 0b011){
            //program gets a store
            store(statePtr->reg[regA]+offsetField, statePtr->reg[regB]);
            statePtr->pc ++;
        }
        else{
            if (statePtr->reg[regA] == statePtr->reg[regB]){
                statePtr->pc += 1 + offsetField;
            }
            else
                statePtr->pc ++;
        }
    }
    else if (ins_bit == 0b000 || ins_bit == 0b001){
        regA = (machine_code>>19) & (0b111);
        regB = (machine_code>>16) & (0b111);
        destreg = (machine_code) & (0b111);
        if (ins_bit == 0b000){
            statePtr->reg[destreg] = statePtr->reg[regA] + statePtr->reg[regB];
            statePtr->pc ++;
        }
        else{
            statePtr->reg[destreg] = ~(statePtr->reg[regA] | statePtr->reg[regB]);
            statePtr->pc ++;
        }
    }
    else if (ins_bit == 0b110 || ins_bit == 0b111){
        if (ins_bit == 0b110){
            statePtr->pc ++;
            return 0;
        }
        else
            statePtr->pc ++;
    }
    else{
        regA = (machine_code>>19) & (0b111);
        regB = (machine_code>>16) & (0b111);
        statePtr->reg[regB] = statePtr->pc + 1;
        statePtr->pc = statePtr->reg[regA];
    }
    return 1;
    //printf("The machine code instruction bits are %d", ins_bit);
}

int main(int argc, const char * argv[]) {
    /*
     #ifdef __APPLE__
     char* outfile = "/Users/helen/Desktop/Jiayu-0.txt";
     freopen(outfile,"w",stdout);
     #endif
    */
    for (int i=0; i<256; i++){
        cache[i][0] = 0;//把每个valid搞成否
        cache[i][3] = 256;//LRU is supposed to be from 0-255,256 means nothing is in the block
    }
    char line[MAXLINELENGTH];
    FILE *filePtr;
    if (argc != 5) {
        printf("error: usage: %s <machine-code file>\n", argv[0]);
        exit(1);
    }
    filePtr = fopen(argv[1], "r");
    if (filePtr == NULL) {
        printf("error: can't open file %s", argv[1]);
        perror("fopen");
        exit(1);
    }
    /* read in the entire machine-code file into memory */
    for (state.numMemory = 0; fgets(line, MAXLINELENGTH, filePtr) != NULL;
         state.numMemory++) {
        if (sscanf(line, "%d", state.mem+state.numMemory) != 1) {
            printf("error in reading address %d\n", state.numMemory);
            exit(1);
        }
        //printf("memory[%d]=%d\n", state.numMemory, state.mem[state.numMemory]);
    }
    blockSizeInWords = atoi(argv[2]);
    numberOfSets = atoi(argv[3]);
    blocksPerSet = atoi(argv[4]);
    totalblocks = numberOfSets*blocksPerSet;
    while(modifyState(&state)){
    }
    return 0;
}






