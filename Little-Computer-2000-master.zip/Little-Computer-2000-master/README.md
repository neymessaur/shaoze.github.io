# Little-Computer-2000
Simulate behavior of a computer based on LC-2K instruction-set architecture.

The project builds LC-2K (Little Computer 2000). LC-2K instruction set is very simple, but it is general enough to solve some complex problems. Please refer to https://github.com/yihellen/Little-Computer-2000/blob/master/LC-2K_simple_explanation.txt for more details. 

This project consists of four parts.

The first part takes an assembly-language program and produce the corresponding machine language. With the generated machine code, I can then simulate the behavior of the program by displaying the changes in register, memory and program counter. 

The second part of the project implements the process of assembling and linking by turning several assembly-language programs into object files and linking them together into one file that consists of the machine code of the previous programs.

The third part of the project is a cycle-accurate behavioral simulator for a pipelined implementation of the LC-2K, complete with data forwarding and simple branch prediction.

The final part of the project simulates the behavior of a CPU cache. The cache will serve the processor simulator from the first part of the project and transfes data or instructions to and from memory for more efficient access. 
