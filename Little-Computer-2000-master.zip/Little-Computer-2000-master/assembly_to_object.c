//
//  main.c
//  assemble
//
//  Created by 益佳宇 on 2018/9/11.
//  Copyright © 2018年 益佳宇. All rights reserved.
//

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAXLINELENGTH 1000
#define MAX_LABEL 6
#define MAX_INS 65536
int readAndParse(FILE *, char *, char *, char *, char *, char *);
int isNumber(char *);
struct symbol_table
{
    char symbol_name[MAXLINELENGTH];
    char symbol_type;
    int offset;
};
struct relocation_table
{
    int offset;
    char op_code[MAXLINELENGTH];
    char label_name[MAXLINELENGTH];
};
struct Address
{
    char label_name[MAXLINELENGTH];
    int address_number;
    int number;
    char op_code[MAXLINELENGTH];
    char arg_0[MAXLINELENGTH];
    char arg_1[MAXLINELENGTH];
    char arg_2[MAXLINELENGTH];
};
int
main(int argc, char *argv[])
{
    char *inFileString, *outFileString;
    FILE *inFilePtr, *outFilePtr;
    char label[MAXLINELENGTH], opcode[MAXLINELENGTH], arg0[MAXLINELENGTH],
    arg1[MAXLINELENGTH], arg2[MAXLINELENGTH];
    int line = 0;/*the number of lines in the assembly-language program*/
    int i = 0;/*the current address that is being specified, i.e. address number*/
    int op_bit;
    int machine_code;
    int regA_bit;
    int regB_bit;
    int dest_bit;
    int mask_3 = 0b111;
    int mask_16 = 0b1111111111111111;
    int offset;
    int symbol_data = 0;/*the number of data in the symbol table*/
    int symbol_text = 0;/*the number of text in the symbol table*/
    int un_label = 1;/*flag for undefined label*/
    int symbol = 0;
    int text = 0;
    int data = 0;
    int symbol_und = 0;/*the number of undefined in the symbol table*/
    
    if (argc != 3) {
        printf("error: usage: %s <assembly-code-file> <machine-code-file>\n",
               argv[0]);
        exit(1);
    }
    
    inFileString = argv[1];
    outFileString = argv[2];
    
    inFilePtr = fopen(inFileString, "r");
    if (inFilePtr == NULL) {
        printf("error in opening %s\n", inFileString);
        exit(1);
    }
    outFilePtr = fopen(outFileString, "w");
    if (outFilePtr == NULL) {
        printf("error in opening %s\n", outFileString);
        exit(1);
    }
    
    /* here is an example for how to use readAndParse to read a line from
     inFilePtr */
    /*get the number of lines in the program*/
    while (readAndParse(inFilePtr, label, opcode, arg0, arg1, arg2)){
        line++;
    }
    //printf("The number of lines is %d\n",line);
    struct Address* command = (struct Address*)malloc(sizeof(struct Address)*line);
    
    if (! readAndParse(inFilePtr, label, opcode, arg0, arg1, arg2) ) {
        /* reached end of file */
    }
    
    /* this is how to rewind the file ptr so that you start reading from the
     beginning of the file */
    rewind(inFilePtr);
    
    /* after doing a readAndParse, you may want to do the following to test the
     opcode */
    
    while (readAndParse(inFilePtr, label, opcode, arg0, arg1, arg2)){
        command[i].address_number = i;
        strcpy(command[i].arg_0, arg0);
        strcpy(command[i].arg_1,arg1);
        strcpy(command[i].arg_2,arg2);
        strcpy(command[i].label_name,label);
        strcpy(command[i].op_code,opcode);
        //printf("The current i is %d, The opcode is %s\n",i,command[i].op_code);
        i++;
    }
    /*count the number of text and data in the file*/
    for (i=0;i<line;i++){
        if (!strcmp(command[i].op_code,".fill"))
            data++;
        else
            text++;
    }
    /*check for duplicated labels*/
    for (i=0;i<line;i++){
        //printf("(i)The label for the %d address is %s\n",i,command[i].label_name);
        for (int j=0;j<line;j++){
            //printf("(j)The label for the %d address is %s\n",j,command[j].label_name);
            if ((strlen(command[i].label_name) != 0)&&(!strcmp(command[i].label_name,command[j].label_name))&&(i != j)){
                printf("The labels in %d line and %d line are the same\n",i,j);
                exit(1);
            }
        }
    }
    /*count the number of data and text in the symbol table*/
    for (i=0;i<line;i++){
        if(command[i].label_name[0]<='Z' && command[i].label_name[0]>='A'){
            symbol++;
            if (!strcmp(command[i].op_code,".fill")){
                symbol_data++;
            }
            else{
                symbol_text++;
            }
        }
    }
    //printf("The current symbol data is %d\n",symbol_data);
    //printf("The current symbol text is %d\n",symbol_text);
    struct symbol_table* data_symbol = (struct symbol_table*)malloc(sizeof(struct symbol_table)*symbol_data);
    struct symbol_table* text_symbol = (struct symbol_table*)malloc(sizeof(struct symbol_table)*symbol_text);
    struct symbol_table* undefined_symbol = (struct symbol_table*)malloc(sizeof(struct symbol_table)*line);
    struct relocation_table relocation[line];/*the relocation table*/
    int relo_ind = 0;/*the index for the relocation table*/
    /*store the global data and global text in the symbol table*/
    int data_symbol_ind = 0;/*the index of data in the symbol table*/
    int text_symbol_ind = 0;/*the index of text in the symbol table*/
    for (i=0;i<line;i++){
        if(command[i].label_name[0]<='Z' && command[i].label_name[0]>='A'){
            if (!strcmp(command[i].op_code,".fill")){
                strcpy(data_symbol[data_symbol_ind].symbol_name,command[i].label_name);
                data_symbol[data_symbol_ind].symbol_type = 'D';
                data_symbol[data_symbol_ind].offset = i-text;
                data_symbol_ind++;
            }
            else{
                strcpy(text_symbol[text_symbol_ind].symbol_name,command[i].label_name);
                text_symbol[text_symbol_ind].symbol_type = 'T';
                text_symbol[text_symbol_ind].offset = i;
                text_symbol_ind++;
            }
        }
    }
    


    for (i=0;i<line;i++){
        un_label = 1;
        if (!strcmp(command[i].op_code, ".fill")){
            if (isNumber(command[i].arg_0)){
                command[i].number = atoi(command[i].arg_0);
            }
            else{
                for (int j=0;j<line;j++){
                    if (!strcmp(command[j].label_name,command[i].arg_0)){
                        command[i].number=command[j].address_number;
                        un_label = 0;/*there is no undefined flags*/
                        strcpy(relocation[relo_ind].label_name,command[i].arg_0);
                        relocation[relo_ind].offset = i-text;
                        strcpy(relocation[relo_ind].op_code,".fill");
                        relo_ind++;
                    }
                }
                if (un_label == 1){
                    if (command[i].arg_0[0]>='A'&&command[i].arg_0[0]<='Z'){
                        int repeat_global = 0;
                        command[i].number = 0;
                        un_label = 0;
                        for (int j=0;j<symbol_und;j++){
                            if (!strcmp(command[i].arg_0, undefined_symbol[j].symbol_name)){
                                strcpy(relocation[relo_ind].label_name,command[i].arg_0);
                                relocation[relo_ind].offset = i-text;
                                strcpy(relocation[relo_ind].op_code,command[i].op_code);
                                relo_ind++;
                                repeat_global = 1;
                                break;
                            }
                        }
                        if (repeat_global == 0){
                            strcpy(undefined_symbol[symbol_und].symbol_name,command[i].arg_0);
                            undefined_symbol[symbol_und].symbol_type = 'U';
                            undefined_symbol[symbol_und].offset = 0;
                            symbol_und++;
                            strcpy(relocation[relo_ind].label_name,command[i].arg_0);
                            relocation[relo_ind].offset = i-text;
                            strcpy(relocation[relo_ind].op_code,".fill");
                            relo_ind++;
                        }
                    }
                    else{
                        printf("The unlabeled item is %s\n",command[i].arg_0);
                        exit(1);
                    }
                }
            }
        }
    }
    
    //printf("The number of the current line 7 is %d\n",command[7].number);

    
    int machine_code_table[line];
    int machine_code_ind = 0;
    for (i=0;i<line;i++){
        if ((!strcmp(command[i].op_code,"lw"))||(!strcmp(command[i].op_code,"sw"))){
            un_label = 1;
            if (!strcmp(command[i].op_code,"lw")){
                op_bit = 0b010;
            }
            else{
                op_bit = 0b011;
            }
            machine_code = op_bit << 22;
            regA_bit = atoi(command[i].arg_0);
            regB_bit = atoi(command[i].arg_1);
            machine_code |= (mask_3 & regA_bit) << 19;
            machine_code |= (mask_3 & regB_bit) << 16;
            //printf("The current machine code is %d\n",machine_code);
            if (isNumber(command[i].arg_2)){
                machine_code |= (atoi(command[i].arg_2) & mask_16);
                offset = atoi(command[i].arg_2);
                if ((offset > 32767)||(offset < -32768)){
                    printf("The offsetFields don't fit in 16 bits!\n");
                    exit(1);
                }
            }
            else{
                for (int j=0;j<line;j++){
                    if (!strcmp(command[j].label_name,command[i].arg_2)){
                        offset = command[j].address_number;
                        if ((offset > 32767)||(offset < -32768)){
                            printf("The offsetFields don't fit in 16 bits!\n");
                            exit(1);
                        }
                        machine_code |= (command[j].address_number & mask_16);
                        un_label = 0;
                        strcpy(relocation[relo_ind].label_name,command[i].arg_2);
                        relocation[relo_ind].offset = i;
                        strcpy(relocation[relo_ind].op_code,command[i].op_code);
                        relo_ind++;
                    }
                }
                if (un_label == 1){
                    if(command[i].arg_2[0]<='Z' && command[i].arg_2[0]>='A'){
                        int repeat_global = 0;/*to see whether there is duplicate global variable*/
                        //printf("The current label is %s\n",command[i].arg_2);
                        machine_code |= (0 & mask_16);
                        for (int j=0;j<symbol_und;j++){
                            if (!strcmp(command[i].arg_2, undefined_symbol[j].symbol_name)){
                                strcpy(relocation[relo_ind].label_name,command[i].arg_2);
                                relocation[relo_ind].offset = i;
                                strcpy(relocation[relo_ind].op_code,command[i].op_code);
                                relo_ind++;
                                repeat_global = 1;
                                break;
                            }
                        }
                        if (repeat_global == 0){
                            strcpy(undefined_symbol[symbol_und].symbol_name,command[i].arg_2);
                            undefined_symbol[symbol_und].symbol_type = 'U';
                            undefined_symbol[symbol_und].offset = 0;
                            symbol_und++;
                            strcpy(relocation[relo_ind].label_name,command[i].arg_2);
                            relocation[relo_ind].offset = i;
                            strcpy(relocation[relo_ind].op_code,command[i].op_code);
                            relo_ind++;
                        }
                    }
                    else{
                        printf("The unlabeled item is %s\n",command[i].arg_2);
                        exit(1);
                    }
                }
            }
            machine_code_table[machine_code_ind] = machine_code;
            machine_code_ind++;
        }
        else if ((!strcmp(command[i].op_code,"beq"))){
            un_label = 1;
            op_bit = 0b100;
            machine_code = op_bit << 22;
            regA_bit = atoi(command[i].arg_0);
            regB_bit = atoi(command[i].arg_1);
            machine_code |= (mask_3 & regA_bit) << 19;
            machine_code |= (mask_3 & regB_bit) << 16;
            if (isNumber(command[i].arg_2)){
                offset = atoi(command[i].arg_2);
                if ((offset > 32767)||(offset < -32768)){
                    printf("The offsetFields don't fit in 16 bits!\n");
                    exit(1);
                }
                machine_code |= (atoi(command[i].arg_2) & mask_16);
            }
            else{
                for (int j=0;j<line;j++){
                    if (!strcmp(command[j].label_name,command[i].arg_2)){
                        offset = command[j].address_number-1-command[i].address_number;
                        if ((offset > 32767)||(offset < -32768)){
                            printf("The offsetFields don't fit in 16 bits!\n");
                            exit(1);
                        }
                        machine_code |= (offset & mask_16);
                        un_label = 0;

                    }
                }
                if (un_label == 1){
                    if(command[i].arg_2[0]<='Z' && command[i].arg_2[0]>='A'){
                        printf("Global undefined variable\n");
                        exit(1);
                    }
                    else{
                        printf("The unlabeled item is %s\n",command[i].arg_2);
                        exit(1);
                    }
                }
            }
            machine_code_table[machine_code_ind] = machine_code;
            machine_code_ind++;
        }
        else if ((!strcmp(command[i].op_code,"add"))||(!strcmp(command[i].op_code,"nor"))){
            if (!strcmp(command[i].op_code,"add")) {
                op_bit = 0b000;
            }
            else{
                op_bit = 0b001;
            }
            machine_code = op_bit << 22;
            regA_bit = atoi(command[i].arg_0);
            regB_bit = atoi(command[i].arg_1);
            machine_code |= (mask_3 & regA_bit) << 19;
            machine_code |= (mask_3 & regB_bit) << 16;
            dest_bit = atoi(command[i].arg_2);
            machine_code |= (mask_16 & dest_bit);
            machine_code_table[machine_code_ind] = machine_code;
            machine_code_ind++;
        }
        else if ((!strcmp(command[i].op_code,"halt"))||(!strcmp(command[i].op_code,"noop"))){
            if (!strcmp(command[i].op_code,"halt")){
                op_bit = 0b110;
            }
            else{
                op_bit = 0b111;
            }
            machine_code = op_bit << 22;
            machine_code_table[machine_code_ind] = machine_code;
            machine_code_ind++;
        }
        else if ((!strcmp(command[i].op_code,"jalr"))){
            op_bit = 0b101;
            machine_code = op_bit << 22;
            regA_bit = atoi(command[i].arg_0);
            regB_bit = atoi(command[i].arg_1);
            machine_code |= (mask_3 & regA_bit) << 19;
            machine_code |= (mask_3 & regB_bit) << 16;
            machine_code_table[machine_code_ind] = machine_code;
            machine_code_ind++;
        }
        else if ((!strcmp(command[i].op_code,".fill"))){
            machine_code = command[i].number;
            machine_code_table[machine_code_ind] = machine_code;
            machine_code_ind++;
        }
        else{
            printf("Unindentified opcode %s\n",command[i].op_code);
            exit(1);
        }
        
    }
    fprintf(outFilePtr,"%d %d %d %d\n",text,data,text_symbol_ind+data_symbol_ind+symbol_und,relo_ind);
    for (i=0;i<machine_code_ind;i++){
        fprintf(outFilePtr,"%d\n",machine_code_table[i]);
    }
    //free(machine_code_table);
    //printf("Here is the symbol table\n");
    for (i=0;i<symbol_text;i++){
        fprintf(outFilePtr,"%s %c %d\n",text_symbol[i].symbol_name,text_symbol[i].symbol_type,text_symbol[i].offset);
    }
    for (i=0;i<symbol_data;i++){
        fprintf(outFilePtr,"%s %c %d\n",data_symbol[i].symbol_name,data_symbol[i].symbol_type,data_symbol[i].offset);
    }
    for (i=0;i<symbol_und;i++){
        fprintf(outFilePtr,"%s %c %d\n",undefined_symbol[i].symbol_name,undefined_symbol[i].symbol_type,undefined_symbol[i].offset);
    }
    //printf("Here is the relocation table\n");
    for (i=0;i<relo_ind;i++){
        fprintf(outFilePtr,"%d %s %s\n",relocation[i].offset,relocation[i].op_code,relocation[i].label_name);
    }
    free(command);
    free(undefined_symbol);
    free(data_symbol);
    free(text_symbol);
    fclose(inFilePtr);
    fclose(outFilePtr);
    exit(0);
}

/*
 * Read and parse a line of the assembly-language file.  Fields are returned
 * in label, opcode, arg0, arg1, arg2 (these strings must have memory already
 * allocated to them).
 *
 * Return values:
 *     0 if reached end of file
 *     1 if all went well
 *
 * exit(1) if line is too long.
 */
int
readAndParse(FILE *inFilePtr, char *label, char *opcode, char *arg0,
             char *arg1, char *arg2)
{
    char line[MAXLINELENGTH];
    char *ptr = line;
    
    /* delete prior values */
    label[0] = opcode[0] = arg0[0] = arg1[0] = arg2[0] = '\0';
    
    /* read the line from the assembly-language file */
    if (fgets(line, MAXLINELENGTH, inFilePtr) == NULL) {
        /* reached end of file */
        return(0);
    }
    
    /* check for line too long (by looking for a \n) */
    if (strchr(line, '\n') == NULL) {
        /* line too long */
        printf("error: line too long\n");
        exit(1);
    }
    
    /* is there a label? */
    ptr = line;
    if (sscanf(ptr, "%[^\t\n\r ]", label)) {
        /* successfully read label; advance pointer over the label */
        ptr += strlen(label);
    }
    
    /*
     * Parse the rest of the line.  Would be nice to have real regular
     * expressions, but scanf will suffice.
     */
    sscanf(ptr, "%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]",
           opcode, arg0, arg1, arg2);
    return(1);
}

int
isNumber(char *string)
{
    /* return 1 if string is a number */
    int i;
    return( (sscanf(string, "%d", &i)) == 1);
}
