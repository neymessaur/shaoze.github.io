//
//  main.c
//  project3
//
//  Created by 益佳宇 on 2018/11/17.
//  Copyright © 2018年 益佳宇. All rights reserved.
//
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define NUMMEMORY 65536 /* maximum number of data words in memory */
#define NUMREGS 8 /* number of machine registers */
#define MAXLINELENGTH 1000
#define ADD 0
#define NOR 1
#define LW 2
#define SW 3
#define BEQ 4
#define JALR 5 /* JALR will not implemented for Project 3 */
#define HALT 6
#define NOOP 7

#define NOOPINSTRUCTION 0x1c00000

typedef struct IFIDStruct {
    int instr;
    int pcPlus1;
} IFIDType;

typedef struct IDEXStruct {
    int instr;
    int pcPlus1;
    int readRegA;
    int readRegB;
    int offset;
} IDEXType;

typedef struct EXMEMStruct {
    int instr;
    int branchTarget;
    int aluResult;
    int readRegB;
} EXMEMType;

typedef struct MEMWBStruct {
    int instr;
    int writeData;
} MEMWBType;

typedef struct WBENDStruct {
    int instr;
    int writeData;
} WBENDType;

typedef struct stateStruct {
    int pc;
    int instrMem[NUMMEMORY];
    int dataMem[NUMMEMORY];
    int reg[NUMREGS];
    int numMemory;
    IFIDType IFID;
    IDEXType IDEX;
    EXMEMType EXMEM;
    MEMWBType MEMWB;
    WBENDType WBEND;
    int cycles; /* number of cycles run so far */
} stateType;

int
field0(int instruction)
{
    return( (instruction>>19) & 0x7);
}

int
field1(int instruction)
{
    return( (instruction>>16) & 0x7);
}

int
field2(int instruction)
{
    return(instruction & 0xFFFF);
}

int
field3(int instruction){
    return(instruction & 0x7);
}
int
opcode(int instruction)
{
    return(instruction>>22);
}
/*从16位二补数计算int*/
int power(int base, int p){
    int result = 1;
    for (int i=0; i<p; i++){
        result = result*base;
    }
    return result;
}
int convertNum(int original){
    int result = 0;
    if (((original >> 15) & 0b1) == 1){
        for (int i=0; i<16; i++){
            if (((original >> i) & 0b1) == 0){
                result += power(2,i);
            }
        }
        result++;
        result = (-1)*result;
    }
    else
        result = original;
    return (result);
}

void
printInstruction(int instr)
{
    
    char opcodeString[10];
    
    if (opcode(instr) == ADD) {
        strcpy(opcodeString, "add");
    } else if (opcode(instr) == NOR) {
        strcpy(opcodeString, "nor");
    } else if (opcode(instr) == LW) {
        strcpy(opcodeString, "lw");
    } else if (opcode(instr) == SW) {
        strcpy(opcodeString, "sw");
    } else if (opcode(instr) == BEQ) {
        strcpy(opcodeString, "beq");
    } else if (opcode(instr) == JALR) {
        strcpy(opcodeString, "jalr");
    } else if (opcode(instr) == HALT) {
        strcpy(opcodeString, "halt");
    } else if (opcode(instr) == NOOP) {
        strcpy(opcodeString, "noop");
    } else {
        strcpy(opcodeString, "data");
    }
    printf("%s %d %d %d\n", opcodeString, field0(instr), field1(instr),
           field2(instr));
}
void
printState(stateType *statePtr)
{
    int i;
    printf("\n@@@\nstate before cycle %d starts\n", statePtr->cycles);
    printf("\tpc %d\n", statePtr->pc);
    
    printf("\tdata memory:\n");
    for (i=0; i<statePtr->numMemory; i++) {
        printf("\t\tdataMem[ %d ] %d\n", i, statePtr->dataMem[i]);
    }
    printf("\tregisters:\n");
    for (i=0; i<NUMREGS; i++) {
        printf("\t\treg[ %d ] %d\n", i, statePtr->reg[i]);
    }
    printf("\tIFID:\n");
    printf("\t\tinstruction ");
    printInstruction(statePtr->IFID.instr);
    printf("\t\tpcPlus1 %d\n", statePtr->IFID.pcPlus1);
    printf("\tIDEX:\n");
    printf("\t\tinstruction ");
    printInstruction(statePtr->IDEX.instr);
    printf("\t\tpcPlus1 %d\n", statePtr->IDEX.pcPlus1);
    printf("\t\treadRegA %d\n", statePtr->IDEX.readRegA);
    printf("\t\treadRegB %d\n", statePtr->IDEX.readRegB);
    printf("\t\toffset %d\n", statePtr->IDEX.offset);
    printf("\tEXMEM:\n");
    printf("\t\tinstruction ");
    printInstruction(statePtr->EXMEM.instr);
    printf("\t\tbranchTarget %d\n", statePtr->EXMEM.branchTarget);
    printf("\t\taluResult %d\n", statePtr->EXMEM.aluResult);
    printf("\t\treadRegB %d\n", statePtr->EXMEM.readRegB);
    printf("\tMEMWB:\n");
    printf("\t\tinstruction ");
    printInstruction(statePtr->MEMWB.instr);
    printf("\t\twriteData %d\n", statePtr->MEMWB.writeData);
    printf("\tWBEND:\n");
    printf("\t\tinstruction ");
    printInstruction(statePtr->WBEND.instr);
    printf("\t\twriteData %d\n", statePtr->WBEND.writeData);
}

void run_helper(int instr, int IDEXstr, int writeback, int* regA, int* regB){
    int destReg = -1;
    int sourceReg = -2;
    if (opcode(instr) == ADD || opcode(instr) == NOR){
        destReg = field3(instr);
    }
    else if (opcode(instr) == LW){
        destReg = field1(instr);
    }
    if (opcode(IDEXstr) == ADD || opcode(IDEXstr) == NOR || opcode(IDEXstr) == BEQ){
        sourceReg = field0(IDEXstr);
        if (sourceReg == destReg){
            *regA = writeback;
        }
        sourceReg = field1(IDEXstr);
        if (sourceReg == destReg){
            *regB = writeback;
        }
    }
    else if (opcode(IDEXstr) == LW){
        sourceReg = field0(IDEXstr);
        if (sourceReg == destReg)
            *regA = writeback;
    }
    else if (opcode(IDEXstr) == SW){
        sourceReg = field0(IDEXstr);
        if (sourceReg == destReg)
            *regA = writeback;
        sourceReg = field1(IDEXstr);
        if (sourceReg == destReg)
            *regB = writeback;
    }
}

void run(stateType state, stateType newState){
    int op;
    while(1){
        printState(&state);
        /*check for halt*/
        if (opcode(state.MEMWB.instr) == HALT) {
            printf("machine halted\n");
            printf("total of %d cycles executed\n", state.cycles);
            exit(0);
        }
        newState = state;
        newState.cycles++;
        /* --------------------- IF stage --------------------- */
        newState.IFID.instr = state.instrMem[state.pc];
        newState.IFID.pcPlus1 = state.pc+1;
        newState.pc = state.pc+1;
        /* --------------------- ID stage --------------------- */
        newState.IDEX.instr = state.IFID.instr;
        newState.IDEX.pcPlus1 = state.IFID.pcPlus1;
        op = opcode(state.IFID.instr);
        if (op == LW || op == SW || op == BEQ){
            int A_idx = field0(state.IFID.instr);
            int B_idx = field1(state.IFID.instr);
            newState.IDEX.readRegA = state.reg[A_idx];
            newState.IDEX.readRegB = state.reg[B_idx];
            newState.IDEX.offset = convertNum(state.IFID.instr & 0xFFFF);
        }
        else if (op == ADD || op == NOR){
            int A_idx = field0(state.IFID.instr);
            int B_idx = field1(state.IFID.instr);
            newState.IDEX.readRegA = state.reg[A_idx];
            newState.IDEX.readRegB = state.reg[B_idx];
        }
        int if_stall = 0;
        if (opcode(state.IDEX.instr) == LW){
            int destReg = field1(state.IDEX.instr);
            int sourceReg;
            op = opcode(state.IFID.instr);
            if (op == ADD || op == NOR || op == BEQ){
                sourceReg = field0(state.IFID.instr);
                if (sourceReg == destReg){
                    if_stall = 1;
                }
                sourceReg = field1(state.IFID.instr);
                if (sourceReg == destReg){
                    if_stall = 1;
                }
            }
            else if (op == LW){
                sourceReg = field0(state.IFID.instr);
                if (sourceReg == destReg)
                    if_stall = 1;
            }
            else if (op == SW){
                sourceReg = field0(state.IFID.instr);
                if (sourceReg == destReg)
                    if_stall = 1;
                sourceReg = field1(state.IFID.instr);
                if (sourceReg == destReg)
                    if_stall = 1;
            }
            if (if_stall == 1){
                newState.IDEX.instr = NOOPINSTRUCTION;
                newState.IFID.instr = state.IFID.instr;
                newState.pc = state.pc;
                newState.IFID.pcPlus1 = state.IFID.pcPlus1;
            }
        }
        /* --------------------- EX stage --------------------- */
        newState.EXMEM.instr = state.IDEX.instr;
        /*handling data hazards*/
        run_helper(state.WBEND.instr, state.IDEX.instr, state.WBEND.writeData, &state.IDEX.readRegA, &state.IDEX.readRegB);
        run_helper(state.MEMWB.instr, state.IDEX.instr, state.MEMWB.writeData, &state.IDEX.readRegA, &state.IDEX.readRegB);
        run_helper(state.EXMEM.instr, state.IDEX.instr, state.EXMEM.aluResult, &state.IDEX.readRegA, &state.IDEX.readRegB);
        /*handling data hazards*/
        newState.EXMEM.branchTarget = state.IDEX.pcPlus1 + state.IDEX.offset;
        op = opcode(state.IDEX.instr);
        if (op == NOR)
            newState.EXMEM.aluResult = ~(state.IDEX.readRegA|state.IDEX.readRegB);
        else if (op == ADD)
            newState.EXMEM.aluResult = state.IDEX.readRegA + state.IDEX.readRegB;
        else if (op == LW || op == SW)
            newState.EXMEM.aluResult = state.IDEX.readRegA + state.IDEX.offset;
        else if (op == BEQ){
            if (state.IDEX.readRegA == state.IDEX.readRegB)
                newState.EXMEM.aluResult = 1;
            else
               newState.EXMEM.aluResult = 0;
        }
        newState.EXMEM.readRegB = state.IDEX.readRegB;
        /* --------------------- MEM stage --------------------- */
        newState.MEMWB.instr = state.EXMEM.instr;
        op = opcode(state.EXMEM.instr);
        if (op == BEQ){
            if (state.EXMEM.aluResult == 1){
                newState.pc = state.EXMEM.branchTarget;
                newState.IFID.instr = NOOPINSTRUCTION;
                newState.IDEX.instr = NOOPINSTRUCTION;
                newState.EXMEM.instr = NOOPINSTRUCTION;
            }
        }
        else if (op == ADD || op == NOR ){
            newState.MEMWB.writeData = state.EXMEM.aluResult;
        }
        else if (op == SW){
            newState.dataMem[state.EXMEM.aluResult] = state.EXMEM.readRegB;
        }
        else if (op == LW){
            newState.MEMWB.writeData = state.dataMem[state.EXMEM.aluResult];
        }
        /* --------------------- WB stage --------------------- */
        newState.WBEND.instr = state.MEMWB.instr;
        newState.WBEND.writeData = state.MEMWB.writeData;
        int destReg;
        op = opcode(state.MEMWB.instr);
        if (op == ADD || op == NOR){
            destReg = field3(state.MEMWB.instr);
            newState.reg[destReg] = state.MEMWB.writeData;
        }
        else if (op == LW){
            destReg = field1(state.MEMWB.instr);
            newState.reg[destReg] = state.MEMWB.writeData;
        }
        state = newState; /* this is the last statement before end of the loop.
                           It marks the end of the cycle and updates the
                           current state with the values calculated in this
                           cycle */
    }
}

int main(int argc, const char * argv[]) {
    /*
#ifdef __APPLE__
    char* outfile = "/Users/helen/Documents/UM/370/project/project3/project3/test_p3_spec_out.txt";
    freopen(outfile,"w",stdout);
#endif
     */
    stateType state;
    stateType newState;
    FILE *filePtr;
    char line[MAXLINELENGTH];
    if (argc != 2) {
        printf("error: usage: %s <machine-code file>\n", argv[0]);
        exit(1);
    }
    filePtr = fopen(argv[1], "r");
    if (filePtr == NULL) {
        printf("error: can't open file %s", argv[1]);
        perror("fopen");
        exit(1);
    }
    //initialization
    state.pc = 0;
    for (int i=0; i<NUMREGS; i++){
        state.reg[i] = 0;
    }
    state.IFID.instr = NOOPINSTRUCTION;
    state.IDEX.instr = NOOPINSTRUCTION;
    state.EXMEM.instr = NOOPINSTRUCTION;
    state.MEMWB.instr = NOOPINSTRUCTION;
    state.WBEND.instr = NOOPINSTRUCTION;
    state.cycles = 0;
    for (state.numMemory = 0; fgets(line, MAXLINELENGTH, filePtr) != NULL;
         state.numMemory++) {
        if (sscanf(line, "%d", state.instrMem+state.numMemory) != 1) {
            printf("error in reading address %d\n", state.numMemory);
            exit(1);
        }
        printf("memory[%d]=%d\n", state.numMemory, state.instrMem[state.numMemory]);
    }
    printf("%d memory words\n",state.numMemory);
    printf("        instruction memory:\n");
    for (int i=0; i<state.numMemory; i++){
        printf("                instrMem[ %d ] ",i);
        printInstruction(state.instrMem[i]);
    }
    for (int i=0; i<state.numMemory; i++)
        state.dataMem[i] = state.instrMem[i];
    newState = state;
    run(state,newState);
    return 0;
}
