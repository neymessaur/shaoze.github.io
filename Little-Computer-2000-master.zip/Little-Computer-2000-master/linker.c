#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAXSIZE 300
#define MAXLINELENGTH 1000
#define MAXFILES 6

typedef struct FileData FileData;
typedef struct SymbolTableEntry SymbolTableEntry;
typedef struct RelocationTableEntry RelocationTableEntry;
typedef struct CombinedFiles CombinedFiles;

struct SymbolTableEntry {
	char label[7];
	char location;
	int offset;
};

struct RelocationTableEntry {
	int offset;
	char inst[7];
	char label[7];
	int file;
};

struct FileData {
	int textSize;
	int dataSize;
	int symbolTableSize;
	int relocationTableSize;
	int textStartingLine; // in final executible
	int dataStartingLine; // in final executible
	int text[MAXSIZE];
	int data[MAXSIZE];
	SymbolTableEntry symbolTable[MAXSIZE];
	RelocationTableEntry relocTable[MAXSIZE];
};

struct CombinedFiles {
	int text[MAXSIZE];
	int data[MAXSIZE];
	SymbolTableEntry     symTable[MAXSIZE];
	RelocationTableEntry relocTable[MAXSIZE];
	int textSize;
	int dataSize;
	int symTableSize;
	int relocTableSize;
};

/* convert a 16-bit number into a 32-bit Linux integer */
int convertNum(int num){
    if (num & (1<<15)){
        num -= (1<<16);
    }
    return (num);
}

int main(int argc, char *argv[])
{
	char *inFileString, *outFileString;
	FILE *inFilePtr, *outFilePtr; 
	int i, j;

	if (argc <= 2) {
		printf("error: usage: %s <obj file> ... <output-exe-file>\n",
				argv[0]);
		exit(1);
	}

	outFileString = argv[argc - 1];

	outFilePtr = fopen(outFileString, "w");
	if (outFilePtr == NULL) {
		printf("error in opening %s\n", outFileString);
		exit(1);
	}

	FileData files[MAXFILES];

	//Reads in all files and combines into master
	for (i = 0; i < argc - 2; i++) {
		inFileString = argv[i+1];

		inFilePtr = fopen(inFileString, "r");
		printf("opening %s\n", inFileString);

		if (inFilePtr == NULL) {
			printf("error in opening %s\n", inFileString);
			exit(1);
		}

		char line[MAXLINELENGTH];
		int sizeText, sizeData, sizeSymbol, sizeReloc;

		// parse first line
		fgets(line, MAXSIZE, inFilePtr);
		sscanf(line, "%d %d %d %d",
				&sizeText, &sizeData, &sizeSymbol, &sizeReloc);

		files[i].textSize = sizeText;
		files[i].dataSize = sizeData;
		files[i].symbolTableSize = sizeSymbol;
		files[i].relocationTableSize = sizeReloc;

		// read in text
		int instr;
		for (j = 0; j < sizeText; j++) {
			fgets(line, MAXLINELENGTH, inFilePtr);
			instr = atoi(line);
			files[i].text[j] = instr;
		}

		// read in data
		int data;
		for (j = 0; j < sizeData; j++) {
			fgets(line, MAXLINELENGTH, inFilePtr);
			data = atoi(line);
			files[i].data[j] = data;
		}

		// read in the symbol table
		char label[7];
		char type;
		int addr;
		for (j = 0; j < sizeSymbol; j++) {
			fgets(line, MAXLINELENGTH, inFilePtr);
			sscanf(line, "%s %c %d",
					label, &type, &addr);
			files[i].symbolTable[j].offset = addr;
			strcpy(files[i].symbolTable[j].label, label);
			files[i].symbolTable[j].location = type;
		}

		// read in relocation table
		char opcode[7];
		for (j = 0; j < sizeReloc; j++) {
			fgets(line, MAXLINELENGTH, inFilePtr);
			sscanf(line, "%d %s %s",
					&addr, opcode, label);
			files[i].relocTable[j].offset = addr;
			strcpy(files[i].relocTable[j].inst, opcode);
			strcpy(files[i].relocTable[j].label, label);
			files[i].relocTable[j].file	= i;
		}
		fclose(inFilePtr);
	} // end reading files
    
    int total_text = 0;
    for (i=0;i<argc-2;i++){
        total_text+=files[i].textSize;
    }
    int total_data = 0;
    for (i=0;i<argc-2;i++){
        total_data+=files[i].dataSize;
    }
    int data_previous[argc-2];
    data_previous[0] = 0;
    for (i=1;i<argc-2;i++){
        data_previous[i] = data_previous[i-1] + files[i-1].dataSize;
    }

    int text_previous[argc-2];
    text_previous[0] = 0;
    for(i=1;i<argc-2;i++){
        text_previous[i] = text_previous[i-1]+files[i-1].textSize;
    }
    printf("text_previous[0] is %d\n",text_previous[0]);
    CombinedFiles combined;
    int combined_text_line = 0;
    int combined_data_line = 0;
    //i is the index of the file
    //j is the index of the textline
    //check if Stack is defined by the object file
    for (int file_num = 0; file_num < argc-2; file_num++)
        for (int symbol_line = 0; symbol_line < files[file_num].symbolTableSize;symbol_line++){
            if (!strcmp(files[file_num].symbolTable[symbol_line].label,"Stack") && (files[file_num].symbolTable[symbol_line].location != 'U')) exit(1);
        }
    //check if there is a duplicated defined label
    for (int file_num = 0; file_num < argc-2; file_num++)
        for (int symbol_line = 0; symbol_line < files[file_num].symbolTableSize;symbol_line++){
            for (int ii = 0;ii< argc-2;ii++)
                for (int jj =0;jj<files[ii].symbolTableSize;jj++){
                    if (!strcmp(files[file_num].symbolTable[symbol_line].label, files[ii].symbolTable[jj].label) && !(ii == file_num && jj == symbol_line) && files[file_num].symbolTable[symbol_line].location != 'U' && files[ii].symbolTable[jj].location != 'U')
                        exit(1);
                }
        }
    
    
    for (i=0;i<argc-2;i++){
        for (j=0;j<files[i].textSize;j++){
            int mc = files[i].text[j];
            int ins_bit = (mc>>22) & (0b111);
            int regA;
            int regB;
            int offsetField;
            regA = (mc>>19) & (0b111);
            regB = (mc>>16) & (0b111);
            offsetField = convertNum((mc) & (0xFFFF));
            //int destreg;
            //if the instruction is lw,sw or beq
            if (ins_bit == 0b010 || ins_bit == 0b011){
                for (int temp = 0; temp < files[i].relocationTableSize;temp++){//iterate through the location table, temp is the line number in the relocation table
                    if (files[i].relocTable[temp].offset == j && (!strcmp(files[i].relocTable[temp].inst,"lw") || !strcmp(files[i].relocTable[temp].inst,"sw"))){
                        if (!strcmp(files[i].relocTable[temp].label,"Stack")){
                            offsetField = total_text+total_data;
                            break;
                        }
                        if (files[i].relocTable[temp].label[0]>='a' && files[i].relocTable[temp].label[0] <='z'){//if it's a locally defined symbol address
                            if (offsetField >= files[i].textSize){//the label refers to an address in the data session
                                offsetField = offsetField - files[i].textSize + total_text + data_previous[i];
                            }
                            else{//the label refers to an address in the text session
                                offsetField = offsetField + text_previous[i];
                            }
                        }
                        else{//if it is globally defined,iterate through the symbol table of all the object files and find the symbol
                            int defined = 0;
                            for (int file_num = 0; file_num < argc-2; file_num++){
                                for (int symbol_line = 0; symbol_line < files[file_num].symbolTableSize;symbol_line++){
                                    if (!strcmp(files[file_num].symbolTable[symbol_line].label,files[i].relocTable[temp].label) && files[file_num].symbolTable[symbol_line].location == 'D'){
                                        defined = 1;
                                        offsetField = total_text + files[file_num].symbolTable[symbol_line].offset + data_previous[file_num];
                                        printf("The offset is %d = %d + %d + %d.\n",offsetField,total_text,files[file_num].symbolTable[symbol_line].offset,data_previous[file_num]);
                                    }
                                    if (!strcmp(files[file_num].symbolTable[symbol_line].label,files[i].relocTable[temp].label) && files[file_num].symbolTable[symbol_line].location == 'T'){
                                        defined = 1;
                                        offsetField = text_previous[file_num] + files[file_num].symbolTable[symbol_line].offset;
                                    }
                                }
                            }
                            if (defined == 0) exit(1);
                        }
                    }
                }
            }
            mc = 0;
            mc = ins_bit << 22;
            mc |= (0b111 & regA) << 19;
            mc |= (0b111 & regB) << 16;
            mc |= (offsetField & 0b1111111111111111);
            printf("The added machine code from file %d textline %d is %d.\n",i,j,mc);
            combined.text[combined_text_line] = mc;
            combined_text_line++;
        }
        printf("text_previous[0] is %d\n",text_previous[0]);
        for (int dataline=0;dataline<files[i].dataSize;dataline++){
            for (int temp = 0; temp < files[i].relocationTableSize;temp++){
                if (files[i].relocTable[temp].offset == dataline && (!strcmp(files[i].relocTable[temp].inst,".fill"))){
                    if (!strcmp(files[i].relocTable[temp].label,"Stack")){
                        files[i].data[dataline] = total_text+total_data;
                        break;
                    }
                    if (files[i].relocTable[temp].label[0]>='a' && files[i].relocTable[temp].label[0] <='z'){//if it's a locally defined symbol address
                        if (files[i].data[dataline] >= files[i].textSize){//the data refers to an address in the data session
                            files[i].data[dataline] = files[i].data[dataline] - files[i].textSize + total_text + data_previous[i];
                        }
                        else{//the label refers to an address in the text session
                            files[i].data[dataline] = files[i].data[dataline] + text_previous[i];
                        }
                    }
                    else{
                        int defined = 0;
                        for (int file_num = 0; file_num < argc-2; file_num++){
                            for (int symbol_line = 0; symbol_line < files[file_num].symbolTableSize;symbol_line++){
                                if (!strcmp(files[file_num].symbolTable[symbol_line].label,files[i].relocTable[temp].label) && files[file_num].symbolTable[symbol_line].location == 'D'){
                                    defined = 1;
                                    files[i].data[dataline] = total_text + files[file_num].symbolTable[symbol_line].offset + data_previous[file_num];
                                    printf("%d = %d + %d + %d\n",files[i].data[dataline],total_text,files[file_num].symbolTable[symbol_line].offset,data_previous[file_num]);
                                }
                                if (!strcmp(files[file_num].symbolTable[symbol_line].label,files[i].relocTable[temp].label) && files[file_num].symbolTable[symbol_line].location == 'T'){
                                    defined = 1;
                                    files[i].data[dataline] = text_previous[file_num] + files[file_num].symbolTable[symbol_line].offset;
                                    printf("%d = %d + %d\n",files[i].data[dataline],text_previous[file_num],files[file_num].symbolTable[symbol_line].offset);
                                }
                            }
                        }
                        if (defined == 0) exit(1);
                    }
                }
            }
            int mc = files[i].data[dataline];
            combined.data[combined_data_line] = mc;
            combined_data_line++;
        }
    }
    for (i=0;i<combined_text_line;i++){
        fprintf(outFilePtr,"%d\n",combined.text[i]);
    }
    for (i=0;i<combined_data_line;i++){
        fprintf(outFilePtr,"%d\n",combined.data[i]);
    }
    return 0;
} // end main
