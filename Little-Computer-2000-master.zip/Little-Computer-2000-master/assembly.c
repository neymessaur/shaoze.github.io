//
//  main.c
//  assemble
//
//  Created by 益佳宇 on 2018/9/11.
//  Copyright © 2018年 益佳宇. All rights reserved.
//

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAXLINELENGTH 1000
#define MAX_LABEL 6
int readAndParse(FILE *, char *, char *, char *, char *, char *);
int isNumber(char *);
struct Address
{
    char label_name[MAXLINELENGTH];
    int address_number;
    int number;
    char op_code[MAXLINELENGTH];
    char arg_0[MAXLINELENGTH];
    char arg_1[MAXLINELENGTH];
    char arg_2[MAXLINELENGTH];
};
int
main(int argc, char *argv[])
{
    char *inFileString, *outFileString;
    FILE *inFilePtr, *outFilePtr;
    char label[MAXLINELENGTH], opcode[MAXLINELENGTH], arg0[MAXLINELENGTH],
    arg1[MAXLINELENGTH], arg2[MAXLINELENGTH];
    int line = 0;/*the number of lines in the assembly-language program*/
    int i = 0;/*the current address that is being specified, i.e. address number*/
    int op_bit;
    int machine_code;
    int regA_bit;
    int regB_bit;
    int dest_bit;
    int mask_3 = 0b111;
    int mask_16 = 0b1111111111111111;
    int offset;
    int un_label = 1;/*flag for undefined label*/
    if (argc != 3) {
        printf("error: usage: %s <assembly-code-file> <machine-code-file>\n",
               argv[0]);
        exit(1);
    }
    
    inFileString = argv[1];
    outFileString = argv[2];
    
    inFilePtr = fopen(inFileString, "r");
    if (inFilePtr == NULL) {
        printf("error in opening %s\n", inFileString);
        exit(1);
    }
    outFilePtr = fopen(outFileString, "w");
    if (outFilePtr == NULL) {
        printf("error in opening %s\n", outFileString);
        exit(1);
    }
    
    /* here is an example for how to use readAndParse to read a line from
     inFilePtr */
    /*get the number of lines in the program*/
    while (readAndParse(inFilePtr, label, opcode, arg0, arg1, arg2)){
        line++;
    }
    //printf("The number of lines is %d\n",line);
    struct Address* command = (struct Address*)malloc(sizeof(struct Address)*line);
    
    if (! readAndParse(inFilePtr, label, opcode, arg0, arg1, arg2) ) {
        /* reached end of file */
    }
    
    /* this is how to rewind the file ptr so that you start reading from the
     beginning of the file */
    rewind(inFilePtr);
    
    /* after doing a readAndParse, you may want to do the following to test the
     opcode */
    
    while (readAndParse(inFilePtr, label, opcode, arg0, arg1, arg2)){
        command[i].address_number = i;
        strcpy(command[i].arg_0, arg0);
        strcpy(command[i].arg_1,arg1);
        strcpy(command[i].arg_2,arg2);
        strcpy(command[i].label_name,label);
        strcpy(command[i].op_code,opcode);
        //printf("The current i is %d, The opcode is %s\n",i,command[i].op_code);
        i++;
    }
    /*check for duplicated labels*/
    for (i=0;i<line;i++){
        //printf("(i)The label for the %d address is %s\n",i,command[i].label_name);
        for (int j=0;j<line;j++){
            //printf("(j)The label for the %d address is %s\n",j,command[j].label_name);
            if ((strlen(command[i].label_name) != 0)&&(!strcmp(command[i].label_name,command[j].label_name))&&(i != j)){
                printf("The labels in %d line and %d line are the same\n",i,j);
                exit(1);
            }
        }
    }
    for (i=0;i<line;i++){
        if (!strcmp(command[i].op_code, ".fill")){
            if (isNumber(command[i].arg_0)){
                command[i].number = atoi(command[i].arg_0);
            }
            else{
                for (int j=0;j<line;j++){
                    if (!strcmp(command[j].label_name,command[i].arg_0)){
                        command[i].number=command[j].address_number;
                        un_label = 0;/*there is no undefined flags*/
                    }
                }
                if (un_label == 1){
                    printf("The unlabeled item is %s\n",command[i].arg_0);
                    exit(1);
                }
            }
        }
    }
    un_label = 1;/*reset the flag*/
//    for (i=0;i<line;i++){
//        if (!strcmp(command[i].op_code, ".fill")){
//            printf("The number is %d\n",command[i].number);
//        }
//    }
    
//    printf("The value of i is %d\n",i);
//    printf("command[8].number is %d\n",command[8].number);
//    if (!strcmp(opcode, "add")) {
//        /* do whatever you need to do for opcode "add" */
//    }
    
    for (i=0;i<line;i++){
        if ((!strcmp(command[i].op_code,"lw"))||(!strcmp(command[i].op_code,"sw"))){
            if (!strcmp(command[i].op_code,"lw")){
                op_bit = 0b010;
            }
            else{
                op_bit = 0b011;
            }
            machine_code = op_bit << 22;
            regA_bit = atoi(command[i].arg_0);
            regB_bit = atoi(command[i].arg_1);
            machine_code |= (mask_3 & regA_bit) << 19;
            machine_code |= (mask_3 & regB_bit) << 16;
            //printf("The current machine code is %d\n",machine_code);
            if (isNumber(command[i].arg_2)){
                machine_code |= (atoi(command[i].arg_2) & mask_16);
                offset = atoi(command[i].arg_2);
                if ((offset > 32767)||(offset < -32768)){
                    printf("The offsetFields don't fit in 16 bits!\n");
                    exit(1);
                }
            }
            else{
                for (int j=0;j<line;j++){
                    if (!strcmp(command[j].label_name,command[i].arg_2)){
                        offset = command[j].address_number;
                        if ((offset > 32767)||(offset < -32768)){
                            printf("The offsetFields don't fit in 16 bits!\n");
                            exit(1);
                        }
                        machine_code |= (command[j].address_number & mask_16);
                        un_label = 0;
                    }
                }
                if (un_label == 1){
                    printf("The unlabeled item is %s\n",command[i].arg_2);
                    exit(1);
                }
            }
            fprintf(outFilePtr,"%d\n",machine_code);
        }
        else if ((!strcmp(command[i].op_code,"beq"))){
            un_label = 1;
            op_bit = 0b100;
            machine_code = op_bit << 22;
            regA_bit = atoi(command[i].arg_0);
            regB_bit = atoi(command[i].arg_1);
            machine_code |= (mask_3 & regA_bit) << 19;
            machine_code |= (mask_3 & regB_bit) << 16;
            if (isNumber(command[i].arg_2)){
                offset = atoi(command[i].arg_2);
                if ((offset > 32767)||(offset < -32768)){
                    printf("The offsetFields don't fit in 16 bits!\n");
                    exit(1);
                }
                machine_code |= (atoi(command[i].arg_2) & mask_16);
            }
            else{
                for (int j=0;j<line;j++){
                    if (!strcmp(command[j].label_name,command[i].arg_2)){
                        offset = command[j].address_number-1-command[i].address_number;
                        if ((offset > 32767)||(offset < -32768)){
                            printf("The offsetFields don't fit in 16 bits!\n");
                            exit(1);
                        }
                        machine_code |= (offset & mask_16);
                        un_label = 0;
                    }
                }
                if (un_label == 1){
                    printf("The unlabeled item is %s\n",command[i].arg_2);
                    exit(1);
                }
            }
            fprintf(outFilePtr,"%d\n",machine_code);
        }
        else if ((!strcmp(command[i].op_code,"add"))||(!strcmp(command[i].op_code,"nor"))){
            if (!strcmp(command[i].op_code,"add")) {
                op_bit = 0b000;
            }
            else{
                op_bit = 0b001;
            }
            machine_code = op_bit << 22;
            regA_bit = atoi(command[i].arg_0);
            regB_bit = atoi(command[i].arg_1);
            machine_code |= (mask_3 & regA_bit) << 19;
            machine_code |= (mask_3 & regB_bit) << 16;
            dest_bit = atoi(command[i].arg_2);
            machine_code |= (mask_16 & dest_bit);
            fprintf(outFilePtr,"%d\n",machine_code);
        }
        else if ((!strcmp(command[i].op_code,"halt"))||(!strcmp(command[i].op_code,"noop"))){
            if (!strcmp(command[i].op_code,"halt")){
                op_bit = 0b110;
            }
            else{
                op_bit = 0b111;
            }
            machine_code = op_bit << 22;
            fprintf(outFilePtr,"%d\n",machine_code);
        }
        else if ((!strcmp(command[i].op_code,"jalr"))){
            op_bit = 0b101;
            machine_code = op_bit << 22;
            regA_bit = atoi(command[i].arg_0);
            regB_bit = atoi(command[i].arg_1);
            machine_code |= (mask_3 & regA_bit) << 19;
            machine_code |= (mask_3 & regB_bit) << 16;
            fprintf(outFilePtr,"%d\n",machine_code);
        }
        else if ((!strcmp(command[i].op_code,".fill"))){
            machine_code = command[i].number;
            fprintf(outFilePtr,"%d\n",machine_code);
        }
        else{
            printf("Unindentified opcode %s\n",command[i].op_code);
            exit(1);
        }
    }
    free(command);
    fclose(inFilePtr);
    fclose(outFilePtr);
    exit(0);
}

/*
 * Read and parse a line of the assembly-language file.  Fields are returned
 * in label, opcode, arg0, arg1, arg2 (these strings must have memory already
 * allocated to them).
 *
 * Return values:
 *     0 if reached end of file
 *     1 if all went well
 *
 * exit(1) if line is too long.
 */
int
readAndParse(FILE *inFilePtr, char *label, char *opcode, char *arg0,
             char *arg1, char *arg2)
{
    char line[MAXLINELENGTH];
    char *ptr = line;
    
    /* delete prior values */
    label[0] = opcode[0] = arg0[0] = arg1[0] = arg2[0] = '\0';
    
    /* read the line from the assembly-language file */
    if (fgets(line, MAXLINELENGTH, inFilePtr) == NULL) {
        /* reached end of file */
        return(0);
    }
    
    /* check for line too long (by looking for a \n) */
    if (strchr(line, '\n') == NULL) {
        /* line too long */
        printf("error: line too long\n");
        exit(1);
    }
    
    /* is there a label? */
    ptr = line;
    if (sscanf(ptr, "%[^\t\n\r ]", label)) {
        /* successfully read label; advance pointer over the label */
        ptr += strlen(label);
    }
    
    /*
     * Parse the rest of the line.  Would be nice to have real regular
     * expressions, but scanf will suffice.
     */
    sscanf(ptr, "%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]",
           opcode, arg0, arg1, arg2);
    return(1);
}

int
isNumber(char *string)
{
    /* return 1 if string is a number */
    int i;
    return( (sscanf(string, "%d", &i)) == 1);
}
