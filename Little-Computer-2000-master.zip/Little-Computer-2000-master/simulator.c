//
//  main.c
//  simulator
//
//  Created by 益佳宇 on 2018/9/29.
//  Copyright © 2018年 益佳宇. All rights reserved.
//

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define NUMMEMORY 65536 /* maximum number of words in memory */
#define NUMREGS 8 /* number of machine registers */
#define MAXLINELENGTH 1000

typedef struct stateStruct {
    int pc;
    int mem[NUMMEMORY];
    int reg[NUMREGS];
    int numMemory;
} stateType;

/* convert a 16-bit number into a 32-bit Linux integer */
int convertNum(int num){
    if (num & (1<<15)){
        num -= (1<<16);
    }
    return (num);
}

void printState(stateType *);
int modifyState(stateType *statePtr);

int
main(int argc, char *argv[])
{
    
#ifdef __APPLE__
    char* outfile = "/Users/helen/Documents/UM/370/project/simulator_multiplication/simulator/simulator/out.txt";
    freopen(outfile,"w",stdout);
#endif
    
    int number_ins = 0;
    char line[MAXLINELENGTH];
    stateType state;
    FILE *filePtr;
    
    if (argc != 2) {
        printf("error: usage: %s <machine-code file>\n", argv[0]);
        exit(1);
    }
    
    filePtr = fopen(argv[1], "r");
    if (filePtr == NULL) {
        printf("error: can't open file %s", argv[1]);
        perror("fopen");
        exit(1);
    }
    
    /* read in the entire machine-code file into memory */
    for (state.numMemory = 0; fgets(line, MAXLINELENGTH, filePtr) != NULL;
         state.numMemory++) {
        
        if (sscanf(line, "%d", state.mem+state.numMemory) != 1) {
            printf("error in reading address %d\n", state.numMemory);
            exit(1);
        }
        printf("memory[%d]=%d\n", state.numMemory, state.mem[state.numMemory]);
    }
    
    printState(&state);
    printf("\n");
    while (modifyState(&state) != 0){
        number_ins ++;
        printState(&state);
    }
    printf("machine halted\n");
    printf("total of %d instructions executed\n", number_ins+1);
    printf("final state of machine:\n");
    printState(&state);
    return(0);
}

int modifyState(stateType *statePtr){
    int machine_code = statePtr->mem[statePtr->pc];
    int ins_bit = (machine_code>>22) & (0b111);
    int regA;
    int regB;
    int offsetField;
    int destreg;
    if (ins_bit == 0b010 || ins_bit == 0b011 || ins_bit == 0b100){
        regA = (machine_code>>19) & (0b111);
        regB = (machine_code>>16) & (0b111);
        offsetField = convertNum((machine_code) & (0xFFFF));
        if (ins_bit == 0b010){
            //printf("The simulator has met a lw\n");
            statePtr->reg[regB] = statePtr->mem[statePtr->reg[regA]+offsetField];
            statePtr->pc ++;
            //printf("pc is %d",statePtr->pc);
        }
        else if (ins_bit == 0b011){
            statePtr->mem[statePtr->reg[regA]+offsetField] = statePtr->reg[regB];
            statePtr->pc ++;
        }
        else{
            if (statePtr->reg[regA] == statePtr->reg[regB]){
                statePtr->pc += 1 + offsetField;
            }
            else
                statePtr->pc ++;
        }
    }
    else if (ins_bit == 0b000 || ins_bit == 0b001){
        regA = (machine_code>>19) & (0b111);
        regB = (machine_code>>16) & (0b111);
        destreg = (machine_code) & (0b111);
        if (ins_bit == 0b000){
            statePtr->reg[destreg] = statePtr->reg[regA] + statePtr->reg[regB];
            statePtr->pc ++;
        }
        else{
            statePtr->reg[destreg] = ~(statePtr->reg[regA] | statePtr->reg[regB]);
            statePtr->pc ++;
        }
    }
    else if (ins_bit == 0b110 || ins_bit == 0b111){
        if (ins_bit == 0b110){
            statePtr->pc ++;
            return 0;
        }
        else
            statePtr->pc ++;
    }
    else{
        regA = (machine_code>>19) & (0b111);
        regB = (machine_code>>16) & (0b111);
        statePtr->reg[regB] = statePtr->pc + 1;
        statePtr->pc = statePtr->reg[regA];
    }
    return 1;
    //printf("The machine code instruction bits are %d", ins_bit);
}


void
printState(stateType *statePtr)
{
    int i;
    printf("\n@@@\nstate:\n");
    printf("\tpc %d\n", statePtr->pc);
    printf("\tmemory:\n");
    for (i=0; i<statePtr->numMemory; i++) {
        printf("\t\tmem[ %d ] %d\n", i, statePtr->mem[i]);
    }
    printf("\tregisters:\n");
    for (i=0; i<NUMREGS; i++) {
        printf("\t\treg[ %d ] %d\n", i, statePtr->reg[i]);
    }
    printf("end state\n");
}
